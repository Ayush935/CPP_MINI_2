#include "Functionalities.h"
#include <iostream>

// how to pass 2d array to function
// void Filldata(int &num1, int &num2, int *a)
// {
    
//     std::cin >> num1;

    
//     std::cin >> num2;
    
//     a = new int[num1+num2];
//      int num3{0};
//     // for (int i = 0; i < num1; i++)
//     // {
//     //     for (int i = 0; i < num2; i++)
//     //     {
//     //         std::cin >> num3;
//     //     }
//     // }

//     for(int i=0;i<num1+num2;i++){
//          std::cin>>a[i];
//     }

//     for(int i=0;i<num1+num2;i++){
//          std::cout<<a[i];
//     }
// }

// void Adaptor(int num1, int num2, int a[], ContainerFunction &fns)
// {
//      for(functions fn:fns){
//         fn(num1,num2,a);
//      }
// }

// void DisplaySum(int array[],int num)
// {
//     int sum = 0;
//     // for (int i = 0; i < 2; i++)
//     // {
//     //     for (int j = 0; j < 2; j++)
//     //     {
//     //         sum += a[i][j];
//     //     }
//     // }
    
    
//     for(int i=0;i<num;i++){
//          sum+=array[i];
//     }

//     std::cout << "Display Sum of All rows and columns" << sum << std::endl;
// }











