#include <iostream>
#include "Functionalities.h"
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"

// int a;
// std::cin>>a;

// int num1 = 0;
// std::cin >> num1;

const int row = 10;
const int column = 10;
using functions = std::function<void(int &, int &, int a[row][column])>;
using ContainerFunction = std::vector<functions>;
int main()
{
    int num1 = 0;
    int num2 = 1;

    std::cout << "Enter the number of rows" << std::endl;
    std::cin >> num1;

    std::cout << "Enter the number of columns" << std::endl;
    std::cin >> num2;
    int array[row][column];

    std::cout << "Enter 2D Array " << std::endl;

    /*
       FillData function to fill data
    */

    auto Filldata = [](int &num1, int &num2, int array[row][column])
    {
        for (int i = 0; i < num1; i++)
        {
            for (int j = 0; j < num2; j++)
            {
                std::cin >> array[i][j];
            }
        }
    };

    ContainerFunction fns{
        Filldata};

    Filldata(num1, num2, array);

    /*
      DisplaySum function to sum of all the values
    */
    auto DisplaySum = [&](int array[row][column])
    {
        int sum = 0;
        int count = 0;
        for (int j = 0; j < num1; j++)
        {
            sum = 0;
            for (int i = 0; i < num2; i++)
            {
                sum += array[j][i];
            }
            count++;

            std::cout << "Display Sum of rows" << count << " " << sum << std::endl;
        }
    };

    DisplaySum(array);

    /*
      Display Highest Value in the array
    */
    auto DisplayHighestValue = [&](int array[row][column])
    {
        int highest_value = array[0][0];
        int sum = 0;
        for (int i = 0; i < num1; i++)
        {
            for (int j = 0; j < num2; j++)
            {
                if (highest_value < array[i][j])
                {
                    highest_value = array[i][j];
                }
            }
        }

        std::cout << "Highest Value of all rows and columns " << highest_value << std::endl;
    };

    DisplayHighestValue(array);

    /*
     Display square of last position
    */
    auto DisplaySquareLastPosition = [&](int a[row][column])
    {
        int LastPosition = 0;

        for (int i = 0; i < num1; i++)
        {
            for (int j = 0; j < num2; j++)
            {
                LastPosition = a[i][j];
            }
        }

        std::cout << "Square of last position" << LastPosition * LastPosition << std::endl;
    };

    DisplaySquareLastPosition(array);

    /*
      Display Maximum in each column
    */
    auto DisplayMaximumNumbersInEachColumn = [&](int a[row][column])
    {
        int MaxNumber1 = 0;
        int MaxNumber2 = 0;
        int count1 = 0;
        int count2 = 0;

        // for (int j = 0; j < num1; j++)
        // {
        //     if (MaxNumber1 < a[0][j])
        //     {
        //         MaxNumber1 = a[0][j];
        //     }
        // }

        // for (int j = 0; j < num2; j++)
        // {
        //     if (MaxNumber2 < a[1][j])
        //     {
        //         MaxNumber2 = a[1][j];
        //     }
        // }

        for (int i = 0; i <num2; i++)
        {
            MaxNumber1 = 0;
            for (int j = 0; j < num1; j++)
            {
                if (MaxNumber1 < array[j][i])
                {
                    MaxNumber1 = array[j][i];
                }
            }

            std::cout << "Column " << i << " Highest number is" << MaxNumber1 << std::endl;
        }
        
        // for(int i=0;i<num2;i++){
             
        // }
    };

    DisplayMaximumNumbersInEachColumn(array);
}
