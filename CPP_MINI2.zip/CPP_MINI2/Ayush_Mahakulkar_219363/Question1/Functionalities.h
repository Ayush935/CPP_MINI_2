#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <functional>
#include <vector>

//void Filldata(int& num1, int& num2, int *a);

//void Adaptor(int num1,int num2,int a[],ContainerFunction&);

//void DisplaySum(int array[row][column],int num);

void DisplayHighestValue(int a[], int num);

void DisplaySquareLastPosition(int a[],int num);

void DisplayMaximumNumbersInEachColumn(int a[],int num);

void check(int &n,int &t);
#endif // FUNCTIONALITIES_H
